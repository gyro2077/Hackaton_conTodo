export class eje {
  constructor({eje_id, eje_nombre, eje_observacion}){
    this.eje_id = eje_id;
    this.eje_nombre = eje_nombre;
    this.eje_observacion = eje_observacion;
  }


}