export class Tiene {
  constructor({ REPORTEPROYECTO_ID, EJES_ID }) {
    this.REPORTEPROYECTO_ID = REPORTEPROYECTO_ID;
    this.EJES_ID = EJES_ID;
  }
}
