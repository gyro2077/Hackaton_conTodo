export class CaracteristicaDTO {
  constructor ({caracteristica_id, caracteristica_nombre, caracteristica_descripcion}) 
    {
        this.caracteristica_id = caracteristica_id;     
        this.caracteristica_nombre = caracteristica_nombre;
        this.caracteristica_descripcion = caracteristica_descripcion;
    }
}